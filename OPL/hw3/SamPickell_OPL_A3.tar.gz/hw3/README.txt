/**************************************
Authors: Sam Pickell and Molly Peterson
Date: 4/11/2018
Filename: README.txt
**************************************/

My partner and I both did our best to follow the spec and do this in
OCaml. The structure of the program is largely based on Dr. Wilkes'
class example code.
