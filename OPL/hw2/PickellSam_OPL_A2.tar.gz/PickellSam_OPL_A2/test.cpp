#include <iostream>

int main2()
{

  std::cout << "Couldn't get part 4 working so we weren't sure what to" 
	    << " include, but the program calls for a test." << std::endl;

  return 0;
}
