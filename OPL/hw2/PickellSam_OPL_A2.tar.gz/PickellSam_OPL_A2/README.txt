/***********************************
Authors: Sam Pickell and Molly Peterson
Date: 2/23/2018
**********************************/

We were able to make assignment 2 compile up to the point of the
error recovery. Even after talking with Dr. Wilkes, we were having
trouble trying to figure out part 4, the piping of a test file
and a way to implement and print out the syntax tree.
