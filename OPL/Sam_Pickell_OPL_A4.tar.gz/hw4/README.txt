/****************************************
Programmer: Sam Pickell
Date: 4/27/18
Filename: README.txt
****************************************/

This is my assignment 4, which I worked by myself on. This homework
makes an h file that implements "tombstones" as discussed in class and
in the book.
